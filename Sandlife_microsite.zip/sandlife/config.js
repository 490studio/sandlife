/* =========================================================
   SANDLIFE · CONFIGURACIÓN COMPARTIDA (Catálogo 2027)
   La usan index.html (clientes) y cotizar.html (Ana).
   Para agregar un diseño: copia una línea dentro de "disenos".
   color: true = el cliente puede elegir clave de color.
   ========================================================= */
const SANDLIFE = {
  whatsapp: "5213339929982",
  whatsappVisible: "33 3992 9982",
  email: "hello@sandlife.co.site",
  instagram: "@sandlife.mx",            // cambia por tu usuario real
  ciudad: "Guadalajara, Jal.",
  firma: "Ana Peredo · Sandlife",
  minimo: 50,
  precioBase: 35,
  vigenciaDias: 15,

  colores: [
    { clave: "AR01", nombre: "Arena",  hex: "#D9C3A5" },
    { clave: "VO01", nombre: "Vino",   hex: "#7A1A2E" },
    { clave: "AZ01", nombre: "Azul",   hex: "#244A7A" },
    { clave: "VE01", nombre: "Verde",  hex: "#255E3C" },
    { clave: "CA01", nombre: "Café",   hex: "#6B4127" },
    { clave: "NE01", nombre: "Negro",  hex: "#1A1A1A" },
    { clave: "RO01", nombre: "Rosa",   hex: "#D99AA0" },
    { clave: "LI01", nombre: "Lila",   hex: "#9B82B8" },
    { clave: "BL01", nombre: "Blanco", hex: "#F3F1EC" }
  ],

  colecciones: [
    { id: "bodas", nombre: "Bodas", lineas: ["Dama"], tono: "#D9A5A0",
      nota: "Los cinco diseños se ofrecen tal como aparecen; no se cambia el color.",
      /* coordinado: color de caballero que se SUGIERE (y preselecciona) cuando el cliente elige este diseño de dama.
         ⚠ CONFIRMAR: solo BD05 (dorado → franjas beige) viene de Ana; los demás son propuesta. */
      disenos: [
        { clave: "BD01", nombre: "Magnolias",     foto: "img/bd01.jpg", coordinado: { clave: "C2", color: "VE01", nombre: "Franjas verde" } },
        { clave: "BD02", nombre: "Flores azules", foto: "img/bd02.jpg", coordinado: { clave: "C2", color: "AZ01", nombre: "Franjas azul" } },
        { clave: "BD03", nombre: "Flores rosa",   foto: "img/bd03.jpg", coordinado: { clave: "C2", color: "AR01", nombre: "Franjas beige" } },
        { clave: "BD04", nombre: "Borgoña",       foto: "img/bd04.jpg", coordinado: { clave: "C2", color: "VO01", nombre: "Franjas vino" } },
        { clave: "BD05", nombre: "Champagne",     foto: "img/bd05.jpg", coordinado: { clave: "C2", color: "AR01", nombre: "Franjas beige" } }
      ] },
    { id: "xv", nombre: "XV años", lineas: ["Dama"], tono: "#BDB0DB",
      nota: "Línea pura está disponible en más colores.",
      disenos: [
        { clave: "QC01", nombre: "Jardín encantado", foto: "img/qc01.jpg" },
        { clave: "QC02", nombre: "Línea pura",       foto: "img/qc02.jpg", color: true },
        { clave: "QC03", nombre: "Arte floral",      foto: "img/qc03.jpg" }
      ] },
    { id: "caballero", nombre: "Caballero", lineas: ["Caballero"], tono: "#A8DCC8",
      nota: "Elige tu modelo en el color que prefieras.",
      disenos: [
        { clave: "C2", nombre: "Línea clásica", foto: "img/c2.jpg", color: true },
        { clave: "C3", nombre: "Naturaleza",    foto: "img/c3.jpg", color: true },
        { clave: "C4", nombre: "Esencial",      foto: "img/c4.jpg", color: true }
      ] },
    { id: "cabos", nombre: "Los Cabos", lineas: ["Dama", "Caballero"], tono: "#E6D8C2", grupo: "Destinos",
      disenos: [
        { clave: "LC1", nombre: "El Arco",         foto: "img/lc1.jpg" },
        { clave: "LC2", nombre: "Desierto y mar",  foto: "img/lc2.jpg" },
        { clave: "LC3", nombre: "Ballenas",        foto: "img/lc3.jpg" }
      ] },
    { id: "cancun", nombre: "Cancún", lineas: ["Dama", "Caballero"], tono: "#E6D8C2", grupo: "Destinos",
      disenos: [
        { clave: "CAN1", nombre: "Palmeras",        foto: "img/can1.jpg" },
        { clave: "CAN2", nombre: "Atardecer",       foto: "img/can2.jpg" },
        { clave: "CAN3", nombre: "Tortuga marina",  foto: "img/can3.jpg" }
      ] },
    { id: "vallarta", nombre: "Puerto Vallarta", lineas: ["Dama", "Caballero"], tono: "#E6D8C2", grupo: "Destinos",
      disenos: [
        { clave: "PV1", nombre: "Palmeras y mar", foto: "img/pv1.jpg" },
        { clave: "PV2", nombre: "El Malecón",     foto: "img/pv2.jpg" },
        { clave: "PV3", nombre: "Ballenas",       foto: "img/pv3.jpg" }
      ] },
    { id: "raices", nombre: "Raíces Mexicanas", lineas: ["Dama", "Caballero"], tono: "#7C8450",
      disenos: [
        { clave: "RM1", nombre: "Sarape",        foto: "img/rm1.jpg" },
        { clave: "RM2", nombre: "Papel picado",  foto: "img/rm2.jpg" },
        { clave: "RM3", nombre: "Agave",         foto: "img/rm3.jpg" }
      ] }
  ],

  tiposEvento: ["Boda", "XV años", "Graduación", "Evento corporativo", "Marca / branding", "Destino / viaje", "Otro"],

  condiciones: [
    "Precios en pesos mexicanos (MXN) por par.",
    "Pedido mínimo de 50 pares.",
    "Cantidades por modelo en múltiplos de 50 pares.",
    "La producción inicia con el anticipo y la aprobación del diseño.",
    "Antes del envío se verifica el pedido (tallas y cantidades) con fotografía.",
    "Colores Pantone como referencia; el tono final se valida con muestra física."
  ]
};
